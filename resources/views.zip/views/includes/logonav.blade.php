        <div class="col-md-7 logo">
            <a href="/"><img src="{{ URL::asset('img/logo.png') }}" /></a>
        </div>


        <div class="col-md-4 logonav">
            <ul>
               
                <li><a href="/site/signin">Sign In </a></li>
                <li><a href="/site/how_it_works">How It Works </a></li>
                <li><a href="/site/signup">Sign Up</a></li>
            </ul>
            
        </div>
