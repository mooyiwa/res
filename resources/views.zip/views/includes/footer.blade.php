<div class="footer">
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <p>&copy; 2018.</p>
        </div>
        <div class="offset4 col-md-4">
        </div>
        </div>
    
        
</div><!--class="container" -->
</div> 