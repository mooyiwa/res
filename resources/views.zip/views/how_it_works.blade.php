@extends('layouts.home')

@section('how_it_works')
<ul class="">
@foreach($works as $work)


 <li>
  <p style="font-size: 1.5em">{{ $work->title }}</p>
</li> 

 <li>
  {!! $work->how !!}
</li> 
                

@endforeach
</ul>

@stop



