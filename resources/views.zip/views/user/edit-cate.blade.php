@extends('layouts.user-home')


@section('editcate')


@foreach($cates as $cate)

{!! Form::open(array('url' => '/user/editcate/'.$cate->id, 'action' => 'pagesController@editCate') ) !!}
<ul>	
<li><span class='msg'>{{ @$msg }}</span></li>

<li><div class="input-group-lg">
  {!! Form::text('cate',$cate->cate,array('required','class' => 'form-control' )) !!}
 </div>
</li>

<li><div class="input-group-lg">
{!! Form::submit('Edit Cate',array('class' => 'btn btn-default')) !!}
 </div>
</li>

@endforeach
</ul>
{!! Form::close() !!}

@stop

