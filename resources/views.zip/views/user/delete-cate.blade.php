@extends('layouts.user-home')


@section('deletecate')


@foreach($cates as $cate) 

{!! Form::open(array('url' => '/user/deletecate/'.$cate->id, 'action' => 'pagesController@deleteCate') ) !!}
<ul>
<!--<li><span class='msg'>{{ @$msg }}</span></li>-->

<li><h3>Cate</h3></li>  

<li>
<div class="input-group-lg">
{!! $cate->cate !!}
 </div>
</li> 

<li>
<div class="input-group-lg">
{!! Form::submit('Delete Cate',array('class' => 'btn btn-default')) !!}
 </div>
</li>  


@endforeach 
</ul>
{!! Form::close() !!}  

@stop



