@extends('layouts.user-home')

@section('bio')
{!! Form::open(array('action' => 'pagesController@createCate'))  !!}   
<ul class="">  
<li><span class='msg'>{{ @$msg }}</span></li>

<li><div class="input-group-lg">
<label>New Cate</label>
</div>
</li>


<li><div class="input-group-lg">
  <input type="text" name="cate" class="form-control" placeholder="Category">
 </div>
</li>
 
 <li><div class="input-group-lg">
<button type="submit" name="submit" class="btn btn-default">Create</button> 
</div>
</li>


</ul>

{!! Form::close() !!}

@stop





