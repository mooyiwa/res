@extends('layouts.user-home')

@section('all-cates')


<table class="table">
    <tr><th>Cate</th></tr>
    <tbody id='go'>
        
   @foreach($cates as $cate)
    
    <tr class="bolder">

    <td>{{ $cate->cate }}</td>
        
    <td><a href="/user/editcate/{{$cate->id}}"> <img src="{{ URL::asset('img/edit.png') }}" /> </a></td>
    <td><a href='/user/deletecate/{{$cate->id}}'> <img src="{{ URL::asset('img/delete.png') }}" /> </a></td>
    </tr>
   
    @endforeach
        
</tbody></table> 

@stop