@extends('layouts.home')

@section('top_post')
<table class="top_post" style="position: relative;left: 32px">

@foreach($top_posts as $top_post)
                    <tr><td><img src="{{ URL::asset('post_images') }}/{{$top_post->cate}}.jpg" /></td>
                    <td class="title" style="word-wrap: break-word;">
                        <a href="/post/{{$top_post->id}}"><h4>{{ $top_post->title }}</h4></a>
                        
                    {{ $top_post->fname }}</td>
                    </tr>                    
                                         

@endforeach

</table><br />

@stop

@section('star_listing')
<ul class="star_listing">

@foreach($posts as $post)

                    <li><a href="/post/{{$post->id}}">
                        <h3 style="margin-top: 75px;">{{ $post->title }}</h3></a>
                        
                    {{ $post->fname }}</li>                                                   

@endforeach

</ul>

@stop

@section('tuts_listing')
<ul class="listing">

@foreach($tuts as $tut)

                    <li><a href="/post/{{$tut->id}}">{{ $tut->title }}</a>
                        <br />
                    {{ $tut->fname }}</li>

                                                          
@endforeach

</ul>

@stop

@section('startups')

<!--<div class="feat"><img src="{{ URL::asset('img') }}/startups.jpg" /></div>-->
<ul class="s_list">

@foreach($s_posts as $s_post)

                    <li><a href="/post/{{$s_post->id}}">{{ $s_post->title }}</a>
                        <br />
                    {{ $s_post->fname }}
                        <br /><br />
                    {{ $s_post->cate }}
                   </li>

                                                          

@endforeach

</ul>

@stop



