        <div class="col-md-7 logo">
            <a href="/"><img src="{{ URL::asset('img/logo.png') }}" /></a>
        </div>


        <div class="col-md-5 logonav">
            <ul>
                
                <li><a href="/site/how_it_works">How It Works </a></li>

                <li class='sign'><a href="/site/signin">Sign In </a></li>
                <li class='sign'><a href="/site/signup">Sign up</a></li>
            </ul>
            

        </div>


