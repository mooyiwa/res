@extends('layouts.user-home')

@section('lend_complete')
          
<ul>
<li><span class='msg'>{{ @$msg }}</span> </li>
</ul>

@stop